package com.example.mylibrary;

/**
 * Created by Hubelshank on 6/25/2015.
 */
public class StoredInformation {
    public static String result;
    public static String symbol;
    public static String choice = "Nothing";
    public static String rivalChoice = "Nothing";
}
